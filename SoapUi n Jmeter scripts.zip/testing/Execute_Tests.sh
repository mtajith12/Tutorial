#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Script 		: Execute_Tests.sh
#  Purpose      : Functional/Load Test executor 
#  Author 		: SCM Team 
#  Date Created : 15/04/2015
#  Last Updated : 15/04/2015
#  Change log   : 1. Initial setup of the script - Ramesh Sistla - 15/04/2015 
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Set_Parameters()
{
 
   
		 # COUCHBASE_AUDITLOG_BUCKETNAME property  
		FIND_STR="%COUCHBASE_AUDITLOG_BUCKETNAME%"
		REPL_STR="${CBAlogName}"
		ssh -i ~/.ssh/keystore/$env/${sshfile} bldmgr@${targetip} -C "sed -i 's|$FIND_STR|${REPL_STR}|' ${depfolder}/batchprocessor/conf/pulse.properties" 2>&1 2>/dev/null

		# COUCHBASE_AUDITLOG_PASSWORD property  
		FIND_STR="%COUCHBASE_AUDITLOG_PASSWORD%"
		REPL_STR="${CBAlogPwd}"
		ssh -i ~/.ssh/keystore/$env/${sshfile} bldmgr@${targetip} -C "sed -i 's|$FIND_STR|${REPL_STR}|' ${depfolder}/batchprocessor/conf/pulse.properties" 2>&1 2>/dev/null

	   # 6. Remove redundant files
        echo "Performing cleanup.."
	ssh -i ~/.ssh/keystore/$env/${sshfile} bldmgr@${targetip} -C "rm -rf ${depfolder}/*.zip" 2>&1 2>/dev/null
   
   
}

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  MAIN Module
#             Call : sh $wks/Deploy_bp.sh BatchProcessor 10.217.19.72:8085 pulseadmin $artipwd $ReleaseRevision $Buildno $Environment $Branch \
#                                            $CBFstorePwd $CBCstorePwd $CBLstorePwd $CBAlogPwd ${CBCfgBucketName} ${CBCfgBucketPwd} ${CBSofa} ${CBStool}
#  Parameters Passed 
#       $1   : Test Type (e.g: 0 - Functional or 1 - Load tests)
#       $2   : Git host and port  (e.g: 10.217.19.72:8085)
#       $3   : Git user 
#       $4   : Git user pwd 
#       $5   : Build version (<major>.<minor>.<fix>   e.g. 0.0.1) 
#       $6   : Jenkins build number

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~   

# Script Parameters
TestType="${1}"
GitHostandPort="${2}"
GitUser="${3}"
GitPwd="${4}"
wks=`pwd`

rm -rf testing

git clone http://${GitUser}:${GitPwd}@${GitHostandPort}/scm/pul/testing.git

case "$TestType" in
    Functional)
       echo "Running Functional Tests"
       rm -rf testing/Load
	   mv testing/Functional/* $wks
	   rm -rf testing
       ant api-tests
       ;;
    Load)
        echo "Running Load Tests"
       rm -rf testing/Functional
	   mv testing/Load/* $wks
	   rm -rf Load
       ;;
    *)
       echo "Incorrect Test type specified"
	   exit 1
       ;;
esac



#if [ -d $wks ]
#then 
#  rm -rf $wks/*
#fi

