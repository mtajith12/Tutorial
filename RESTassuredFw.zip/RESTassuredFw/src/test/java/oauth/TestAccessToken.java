package oauth;

import static io.restassured.RestAssured.*;
import io.restassured.path.json.JsonPath;
import static org.hamcrest.Matchers.*;

import org.junit.BeforeClass;
import org.junit.Test;

public class TestAccessToken {

    private static String OAUTH_TOKEN = "";

  //  @BeforeClass
    public static void setup() {
        baseURI = "https://dt.pulsenow.co.uk";

        JsonPath token = given()
                .formParam("client_id", "4cf503aa-b4c8-4133-b30e-c00c418b70eb")
                .formParam("client_secret", "9004d123-4aa9-49be-a07e-591bf285badc")
                .formParam("grant_type", "password")
                .formParam("scope", "test_data")
                .formParam("username", "mt000a")
                .formParam("password", "Api@2611")
                .when()
                .post("/auth/oauth/v2/token")
                .andReturn()
                .jsonPath();

        OAUTH_TOKEN = token.getString("access_token");
        System.out.println(OAUTH_TOKEN);
    }

   // @Test
    public void testPost() {
        given()
                .auth()
                .oauth2(OAUTH_TOKEN)
                .when()
                .post("/api/1332/chickens-feed")
                .then()
                .assertThat()
                .body("action", equalToIgnoringCase("chickens-feed"));

    }

   // @Test
    public void testPostCollect() {
        given()
                .auth()
                .oauth2(OAUTH_TOKEN)
                .when()
                .post("mobile/customerinfo/v2/postcode/DM001PL")
                .then()
                .assertThat()
                .body("action", equalToIgnoringCase("eggs-collect"));


    }

   // @Test
    public void testPostCount() {
        given()
                .auth()
                .oauth2(OAUTH_TOKEN)
                .when()
                .post("/api/1332/eggs-count")
                .then()
                .assertThat()
                .body("action", equalToIgnoringCase("eggs-count"));

    }

  //  @Test
    public void testAccesPriv() {

        given()
                .auth()
                .oauth2(OAUTH_TOKEN)
                .when()
                .get("/api/me")
                .then()
                .assertThat()
                .body("error", equalToIgnoringCase("insufficient_scope"));

    }

}
