package stepdefs;

import config.Endpoint;
import cucumber.ScenarioContext;
import cucumber.TestContext;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import enums.Context;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.junit.BeforeClass;
import org.junit.runner.Request;
import utilities.BaseClass;

import java.util.List;

import static config.Endpoint.GET_OAUTH_TOKEN;
import static io.restassured.RestAssured.get;
import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.when;
import static org.apache.http.HttpStatus.SC_NOT_FOUND;
import static org.apache.http.HttpStatus.SC_OK;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class Test_FDE_endpoints extends BaseClass {
    TestContext testContext;

    private Response response;
    private Request request;
    private static String OAUTH_TOKEN = "";
    protected static String ADDRESS_ID,ID = "";
    private RequestSpecification requestSpec;
    public Test_FDE_endpoints(TestContext context) {
        TestContext testContext;

    }
    @BeforeClass
    public static void setup() {
        // Set Base URI
        setBaseURI();
    }

    @Given("^Engineer login to CI app$")
    public void engineer_login_to_CI_app() throws Throwable {

        setBaseURI();
        OAUTH_TOKEN = getOauthToken();
        //Genarate the oAuth token
//        response = given()
//                .formParam("client_id", "4cf503aa-b4c8-4133-b30e-c00c418b70eb")
//                .formParam("client_secret", "9004d123-4aa9-49be-a07e-591bf285badc")
//                .formParam("grant_type", "password")
//                .formParam("scope", "test_data")
//                .formParam("username", "mt000a")
//                .formParam("password", "Api@2611")
//                //.proxy("http://proxy.fjgslbdmz.uk.centricaplc.com")
//                .when()
//                .post(GET_OAUTH_TOKEN)
//                .andReturn();
//
//        JsonPath token = getJsonPath(response);
//                OAUTH_TOKEN = token.getString("access_token");
//                System.out.println("OAUTH_TOKEN" +OAUTH_TOKEN);
        requestSpec =   given()
                .contentType("Application/JSON")
                .auth()
                .oauth2(OAUTH_TOKEN).log().all();

    }

    @When("^he enters post code of customer \"([^\"]*)\"$")
    public void he_enters_post_code_of_customer(String postCode) throws Throwable {

        response = requestSpec.pathParam("postcode", postCode).
                         when()
                        .get(Endpoint.GET_POSTCODE_LOOKUP).thenReturn();
        response.prettyPrint();
      //  Extracting the Id for the address look up API
        String bodystring = response.getBody().asString();
        JsonPath jsonPath =JsonPath.from(bodystring);
        ID = jsonPath.getString("addresses.id");
        ADDRESS_ID = response.getBody().jsonPath().getString("id");
//        System.out.println("ADDRESS_ID : " +ADDRESS_ID);
//        System.out.println("ADDRESS_ID : " +ID);
//        testContext.scenarioContext.setContext(Context.ADDRESSID, ID);
      //

    }

    @Then("^CI app should display all the address$")
    public void ci_app_should_display_all_the_address() throws Throwable {
        assertEquals("HTTP Status Check Failed!", SC_OK, response.getStatusCode());
        assertTrue("street Check Failed!",  response.body().asString().contains("TESTDOWN"));
        assertTrue("Town Check Failed!",  response.body().asString().contains("KINGSTON"));
        assertTrue("Id Check Failed!",  response.body().asString().contains("dummy08b3d548be3cf5b3f2cee319c1f4277934289c58fb709ee466bc9a8c5fcaedab"));
        assertTrue("House No. Check Failed!",  response.body().asString().contains("1 TESTDOWN"));

    }

    @Given("^Engineer have address id for the mention postcode$")
    public void engineer_have_address_id_for_the_mention_postcode() throws Throwable {
        requestSpec = given ().contentType("Application/JSON").auth().oauth2(OAUTH_TOKEN);
        requestSpec.log().all();
    }

    @When("^he enters address id to findAddressById endpoint \"([^\"]*)\"$")
    public void he_enters_address_id_to_findAddressById_endpoint(String ADDRESS_ID1) throws Throwable {

        response = requestSpec.when().
                get(Endpoint.GET_ADDRESS_BY_POSTCODE).
                thenReturn();
        response.prettyPrint();
    }

    @And("^response should have status '(\\d+)'$")
    public void response_should_have_status(int arg1) throws Throwable {
        assertEquals("HTTP Status Check Failed!", SC_OK, response.getStatusCode());
    }

    @And("^response should have following details '<street>','<town>','<id>','<firstLine>'$")
    public void response_should_have_following_details_street_town_id_firstLine() throws Throwable {
        assertTrue("street Check Failed!",  response.body().asString().contains("TESTDOWN"));
        assertTrue("Town Check Failed!",  response.body().asString().contains("KINGSTON"));
        assertTrue("Postcode Check Failed!",  response.body().asString().contains("DM00 1PL"));
        assertTrue("House No. Check Failed!",  response.body().asString().contains("1"));

    }

    @Then("^test boiler api display all the address$")
    public void testBoilerApiDisplayAllTheAddress() throws Throwable {
        response =  given().
                contentType("Application/JSON").
                when().
                get(Endpoint.GET_BOILERINFO_BY_CRN).thenReturn();
        response.prettyPrint();
    }

    @Given("^Engineer login to CI app to get boiler Info$")
    public void engineerLoginToCIAppToGetBoilerInfo() throws Throwable {

    }


    @And("^response should have error message$")
    public void responseShouldHaveErrorMessage() throws Throwable {
        assertTrue("Errer messaged Check Failed!",  response.body().asString().contains("Invalid UK postcode, postcode must be in the given format TW20 8NJ, including a space."));

    }

    @When("^he enters post code of customer <DM(\\d+)P(\\d+)L>$")
    public void heEntersPostCodeOfCustomerDMPL(int arg0, int arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        throw new PendingException();
    }

    @Then("^response should have status <(\\d+)>$")
    public void responseShouldHaveStatus(int arg0) throws Throwable {
        assertTrue("Error messaged Check Failed!",  response.body().asString().contains("Invalid UK postcode, postcode must be in the given format TW20 8NJ, including a space."));
    }


    @Given("^Engineer have valid OAUTH token to access customer data using to CI app$")
    public void engineerHaveValidOAUTHTokenToAccessCustomerDataUsingToCIApp() throws Throwable {
        requestSpec = given ().contentType("Application/JSON").auth().oauth2(OAUTH_TOKEN);
        requestSpec.log().all();
    }

    @When("^he enters post code of customer DM(\\d+)PL$")
    public void heEntersPostCodeOfCustomerPostcode(String postcode) throws Throwable {
        response = requestSpec.when().pathParam("id",postcode)
                .get(Endpoint.GET_ADDRESS_BY_POSTCODE).thenReturn();

        response.prettyPrint();
    }

    @Then("^response should have status (\\d+)$")
    public void responseShouldHaveStatusStatusCode(String statuscode) throws Throwable {
        assertEquals("HTTP Status Check Failed!", SC_OK, response.getStatusCode());
    }

    @Then("^response should have following details TESTDOWN,KINGSTON,dummy(\\d+)b(\\d+)d(\\d+)be(\\d+)cf(\\d+)b(\\d+)f(\\d+)cee(\\d+)c(\\d+)f(\\d+)c(\\d+)fb(\\d+)ee(\\d+)bc(\\d+)a(\\d+)c(\\d+)fcaedab,(\\d+) TESTDOWN$")
    public void responseShouldHaveFollowingDetailsStreetTownIdFirstLine(DataTable dt) throws Throwable {
        List <List< String >> data = dt.raw();

        assertTrue("street Check Failed!",  response.body().asString().contains(data.get(1).get(0)));
        assertTrue("town Check Failed!",  response.body().asString().contains(data.get(1).get(1)));
        assertTrue("id Check Failed!",  response.body().asString().contains(data.get(1).get(2)));
        assertTrue("firstLine Check Failed!",  response.body().asString().contains(data.get(1).get(3)));

    }

    @When("^he enters invalid post code of customer \"([^\"]*)\"$")
    public void heEntersInvalidPostCodeOfCustomer(String arg0) throws Throwable {
        response = requestSpec.
                    when().
                    get(Endpoint.GET_ADDRESS_BY_POSTCODE).
                    thenReturn();
        response.prettyPrint();
    }

    @Then("^response should have HTTP status (\\d+)$")
    public void responseShouldHaveHTTPStatus(int arg0) throws Throwable {
        assertEquals("HTTP Status Check Failed!", SC_NOT_FOUND, response.getStatusCode());
    }
    @Then("^response should have following error message Invalid UK postcode, postcode must be in the given format TW20 8NJ, including a space$")
    public void response_should_have_following_error_message_Invalid_UK_postcode_postcode_must_be_in_the_given_format_TW_NJ_including_a_space(String message) throws Throwable {
        assertTrue("Error message Check Failed!",  response.body().asString().contains(message));
    }

}
