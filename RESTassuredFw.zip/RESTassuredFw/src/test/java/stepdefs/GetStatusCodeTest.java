package stepdefs;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import static io.restassured.RestAssured.given;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class GetStatusCodeTest {
    private Response response;

    @BeforeClass
    public void setBaseUri () {

        RestAssured.baseURI = "https://dt.pulsenow.co.uk";
    }

    @Test
    public void testStatusCode () {

         response =
                given ()
                        .when()
                        .get ("/boilerinfo/v2/boiler/crn/911000784564");

        Assert.assertEquals (response.statusCode (), 200);
        response.prettyPrint();
    }

    @Test
    public void testStatusCodeRestAssured () {
        assertEquals("HTTP Status Check Failed!", 200, response.getStatusCode());
        assertTrue("Age Check Failed!",  response.body().asString().contains("age"));
        assertTrue("Town Check Failed!",  response.body().asString().contains("make"));
        assertTrue("Id Check Failed!",  response.body().asString().contains("model"));
        assertTrue("House No. Check Failed!",  response.body().asString().contains("owner"));


    }}