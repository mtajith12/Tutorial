package runner;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)

@CucumberOptions(
        features = "src/test/java/resources/Features",
        glue= {"stepdefs"},
        plugin = { "pretty", "com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-html-extent/report.html",
                    "html:target/cucumber-html-default",
                    "json:target/cucumber-report.json" },
        monochrome = true,
        strict = true,
        dryRun = false
      //  tags = {"@API_Test"}//"~@SmokeTest" , "~@RegressionTest", "~@End2End"}

)

public class TestRunner {
 //   @AfterClass
//    public static void writeExtentReport() {
//        Reporter.loadXMLConfig(new File(FileReaderManager.getInstance().getConfigReader().getReportConfigPath()));
//    }
}
